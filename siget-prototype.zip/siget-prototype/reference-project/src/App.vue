<template>
  <router-view />
</template>

<script>
import router from './router';


</script>

<style>

</style>
